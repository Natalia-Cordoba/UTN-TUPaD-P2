/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo.practico1.cordoba;

/**
 *
 * @author natal
 */
public class Ejercicio6 {
    public static void main(String[] args) {
        
        // mostrar mensaje por consola usando caracteres de escape
        System.out.println("Nombre: Juan Pérez\nEdad: 30 años\nDirección: \"Calle Falsa 123\"");
        
    }
}
