/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo.practico1.cordoba;

/**
 *
 * @author natal
 */
public class HolaMundo {
    
    public static void main(String[] args) {
        
        // Ejercicio 2
        // imprimo el mensaje por consola
        System.out.println("¡Hola, Java!");
    }   
}
