/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajo.practico1.cordoba;

/**
 *
 * @author natal
 */
public class Ejercicio3 {
    
    public static void main(String[] args) {
        
        // declarar las variables y asignarles un valor
        String nombre = "Josefina";
        int edad = 23;
        double altura = 1.63;
        boolean estudiante = true;
        
        // mostrar los valores por consola
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Altura: " + altura);
        System.out.println("Estudia: " + estudiante);
        
    }
}
